# Steam Chat Translator — v0.1 diagnostyczna

Ta wersja wyłącznie wykrywa interfejs Friends & Chat oraz elementy wiadomości. Nie korzysta z Google Translate, żadnego API ani połączeń sieciowych.

## Test

1. Włącz wtyczkę w **Millennium Settings > Plugins**.
2. Otwórz **Friends & Chat**, a potem zwykłą rozmowę tekstową.
3. Otwórz **Millennium Settings > Logs** i odszukaj wpisy zaczynające się od `SCT` lub `Steam Chat Translator v0.1`.
4. Oczekiwany wynik: `CHAT DETECTED` oraz liczba `messages` większa od zera po otwarciu rozmowy.

Do raportu z testu wystarczy zrzut strony wtyczek i kilka wpisów logu; nie pokazuj treści prywatnych wiadomości.
