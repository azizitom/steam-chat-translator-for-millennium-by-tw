local logger = require("logger")
local millennium = require("millennium")

require("rpc_functions")

local function on_load()
    logger:info("Steam Chat Translator for Millennium by TW v0.10.1 backend loaded (Millennium " .. millennium.version() .. ")")
    millennium.ready()
end

local function on_frontend_loaded()
    logger:info("Steam UI frontend reported ready; waiting for diagnostic scan logs.")
end

local function on_unload()
    logger:info("Steam Chat Translator for Millennium by TW unloaded.")
end

return {
    on_load = on_load,
    on_frontend_loaded = on_frontend_loaded,
    on_unload = on_unload,
}
