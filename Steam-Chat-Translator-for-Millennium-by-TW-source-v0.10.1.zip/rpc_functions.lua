local logger = require("logger")
local http = require("http")
local json = require("json")
local millennium = require("millennium")

---@ffi
---@param message string
---@return boolean
function reportDiagnostic(message)
    logger:info("UI " .. message)
    return true
end

local supported_languages = {
    pl = true, ru = true, uk = true, en = true, de = true,
    fr = true, es = true, it = true, cs = true,
}

local function configured_language(key, fallback)
    local language = millennium.config.get(key)
    return type(language) == "string" and supported_languages[language] and language or fallback
end

local function translate(text, source, target, log_prefix, skip_same_language)
    if type(text) ~= "string" or text == "" or #text > 5000 or (source and source == target) then return "" end
    local api_key = millennium.config.get("google_api_key")
    if type(api_key) ~= "string" then return "" end
    api_key = api_key:match("^%s*(.-)%s*$")
    if api_key == "" then return "" end

    local payload = { q = text, target = target, format = "text" }
    if source then payload.source = source end
    local response, err = http.request(
        "https://translation.googleapis.com/language/translate/v2?key=" .. api_key .. "&target=" .. target .. "&format=text" .. (source and "&source=" .. source or ""),
        { method = "POST", data = json.encode(payload), headers = { ["Content-Type"] = "application/json; charset=utf-8" }, timeout = 10, verify_ssl = true }
    )
    if not response then
        logger:warn(log_prefix .. " translation request failed: " .. tostring(err))
        return ""
    end
    if response.status < 200 or response.status >= 300 then
        logger:warn(log_prefix .. " translation API HTTP " .. tostring(response.status) .. ": " .. tostring(response.body):sub(1, 500))
        return ""
    end

    local ok, decoded = pcall(json.decode, response.body)
    if not ok or type(decoded) ~= "table" or type(decoded.data) ~= "table" or type(decoded.data.translations) ~= "table" then
        logger:warn(log_prefix .. " translation service returned an unreadable response")
        return ""
    end
    local first = decoded.data.translations[1]
    if type(first) ~= "table" or type(first.translatedText) ~= "string" then
        logger:warn(log_prefix .. " translation service returned no translated text")
        return ""
    end
    if skip_same_language and first.detectedSourceLanguage == target then return "" end
    return first.translatedText
end

---@ffi
---@param text string
---@return string
function translateIncoming(text)
    -- Google detects the source language. Messages already written in the user's
    -- outgoing source language do not receive a redundant translation label.
    return translate(text, nil, configured_language("outgoing_source_language", "pl"), "Incoming", true)
end

---@ffi
---@param text string
---@return string
function translateOutgoing(text)
    return translate(text, configured_language("outgoing_source_language", "pl"), configured_language("outgoing_target_language", "ru"), "Outgoing")
end

---@ffi
---@param request string
---@return string
function translateOutgoingWithLanguages(request)
    local ok, value = pcall(json.decode, request)
    if not ok or type(value) ~= "table" or type(value.text) ~= "string" then return "" end
    local source = type(value.source) == "string" and value.source or "pl"
    local target = type(value.target) == "string" and value.target or "ru"
    if not supported_languages[source] or not supported_languages[target] then return "" end
    return translate(value.text, source, target, "Outgoing")
end

---@ffi
---@param request string
---@return string
function translateIncomingWithLanguages(request)
    local ok, value = pcall(json.decode, request)
    if not ok or type(value) ~= "table" or type(value.text) ~= "string" then return "" end
    local source = type(value.source) == "string" and value.source or "auto"
    local target = type(value.target) == "string" and value.target or "pl"
    if source ~= "auto" and not supported_languages[source] then return "" end
    if not supported_languages[target] then return "" end
    local source_param = nil
    if source ~= "auto" then source_param = source end
    return translate(value.text, source_param, target, "Incoming", source == "auto")
end

---@ffi
---@param request string
---@return boolean
function saveOutgoingLanguages(request)
    local ok, value = pcall(json.decode, request)
    if not ok or type(value) ~= "table" then return false end
    if not supported_languages[value.source] or not supported_languages[value.target] then return false end
    millennium.config.set("outgoing_source_language", value.source)
    millennium.config.set("outgoing_target_language", value.target)
    return true
end

---@ffi
---@param request string
---@return boolean
function saveChatTranslationPreference(request)
    local ok, value = pcall(json.decode, request)
    if not ok or type(value) ~= "table" or type(value.id) ~= "string" or type(value.preference) ~= "table" then return false end
    if #value.id == 0 or #value.id > 180 then return false end
    local preference = value.preference
    local source = type(preference.source) == "string" and preference.source or "auto"
    local target = type(preference.target) == "string" and preference.target or "pl"
    if (source ~= "auto" and not supported_languages[source]) or not supported_languages[target] then return false end
    local existing = millennium.config.get("chat_translation_preferences")
    local decoded_ok, preferences = pcall(json.decode, type(existing) == "string" and existing or "{}")
    if not decoded_ok or type(preferences) ~= "table" then preferences = {} end
    preferences[value.id] = { enabled = preference.enabled == true, source = source, target = target }
    millennium.config.set("chat_translation_preferences", json.encode(preferences))
    return true
end

logger:info("Registered diagnostic and translation RPC functions")
