Steam Chat Translator for Millennium by TW
Version 0.10.1

DESCRIPTION

Steam Chat Translator for Millennium by TW is a Windows Steam add-on.
It translates incoming chat messages and prepares translations for outgoing
messages in selected languages. It uses the Google Cloud Translation API.

Main features:
- choose source and target languages for each outgoing translation;
- display translations of incoming messages in a selected chat window;
- separate translation-view settings in a chat window;
- preview a translation before placing it in the message field;
- send with Steam's normal Send button to avoid accidental duplicate messages.

REQUIREMENTS

- Steam for Windows;
- Millennium for Steam;
- a Google Cloud account with billing enabled;
- a Google Cloud Translation API key.

WHAT IS MILLENNIUM

Millennium is an open-source add-on framework for the desktop Steam client.
It lets Steam use plugins and themes.

Official website and documentation:
https://docs.steambrew.app/

INSTALL MILLENNIUM ON WINDOWS

1. Close Steam.
2. Open the official Millennium installation page:
   https://docs.steambrew.app/users/getting-started/installation
3. Download MillenniumInstaller-Windows.exe from that page.
4. Run the installer and follow its instructions.
5. Start Steam again.
6. Millennium should appear in the Steam menu at the top left.

INSTALL THE PLUGIN

1. Extract the downloaded ZIP archive to any folder.
2. In Steam, open Steam > Millennium > Plugins.
3. Select "Install plugin".
4. Select this file:
   Steam Chat Translator for Millennium by TW.star
5. Enable the plugin with its switch in the plugin list.
6. Open the plugin menu and select "Restart".

FIRST SETUP AND API KEY

IMPORTANT: this plugin needs a Google Cloud Translation API key. It does not
use a Google Maps API key.

1. Open the Google Cloud console:
   https://console.cloud.google.com/
2. Create a project or choose an existing project.
3. Enable billing for the project. Google requires billing for Cloud Translation.
4. Enable Cloud Translation API:
   https://console.cloud.google.com/apis/library/translate.googleapis.com
5. Open Credentials:
   https://console.cloud.google.com/apis/credentials
6. Select "Create credentials" > "API key" and copy the generated key.
7. For security, restrict the key to Cloud Translation API.
8. In Steam, open Millennium > Plugins, open the plugin configuration, and
   paste the key into "Google Cloud Translation API key".

Official Google instructions:
https://cloud.google.com/translate/docs/setup
https://cloud.google.com/docs/authentication/api-keys

HOW TO USE

1. Open a Steam chat window.
2. The translation icon beside the message field opens an outgoing-translation
   preview. Choose source and target languages, then select "Insert text".
   Click Steam's normal send arrow to send the message.
3. The eye icon opens incoming-translation settings for the current chat:
   choose source and target languages and turn the translation display on or off.

SECURITY AND COSTS

Your API key is private. Do not share it, and restrict it to Cloud Translation
API only. Google Cloud services can incur charges; review usage and quotas in
the Google Cloud console.

OFFICIAL LINKS

Millennium: https://docs.steambrew.app/
Millennium installation: https://docs.steambrew.app/users/getting-started/installation
Google Cloud Translation: https://cloud.google.com/translate/docs/setup
API key management: https://cloud.google.com/docs/authentication/api-keys
