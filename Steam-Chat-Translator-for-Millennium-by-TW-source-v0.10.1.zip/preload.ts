const PREFIX = "[Steam Chat Translator for Millennium by TW / webview]";

const MESSAGE_SELECTORS = [
  '[class*="ChatMessage"]',
  '[class*="ChatEntry"]',
  '[class*="MessageBody"]',
  '[class*="messageContent"]',
];
let lastSignature = "";
let scanQueued = false;

function report(message: string): void {
  void backend.reportDiagnostic(`WEBVIEW ${message}`);
}

function scan(reason: string): void {
  const found = new Set<Element>();
  for (const selector of MESSAGE_SELECTORS) {
    document.querySelectorAll(selector).forEach((element) => found.add(element));
  }
  const inputs = document.querySelectorAll('textarea, [contenteditable="true"], input[type="text"]').length;
  const signature = `${document.title}|${found.size}|${inputs}`;
  if (reason === "mutation" && signature === lastSignature) return;
  lastSignature = signature;
  report(`scan=${reason}: title=${document.title || "(none)"}; messages=${found.size}; inputs=${inputs}`);
}

export default async function main() {
  report(`loaded: url=${location.href}; title=${document.title || "(none)"}`);
  window.setTimeout(() => scan("initial"), 1000);
  const observer = new MutationObserver(() => {
    if (scanQueued) return;
    scanQueued = true;
    window.setTimeout(() => {
      scanQueued = false;
      scan("mutation");
    }, 300);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
}
