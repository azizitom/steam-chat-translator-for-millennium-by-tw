Steam Chat Translator for Millennium by TW
Wersja 0.10.1

OPIS

Steam Chat Translator for Millennium by TW to dodatek do aplikacji Steam dla Windows.
Tłumaczy wiadomości przychodzące i przygotowuje tłumaczenia wiadomości wychodzących
w wybranych językach. Do działania używa Google Cloud Translation API.

Najważniejsze funkcje:
- wybór języka źródłowego i docelowego osobno dla wysyłanej wiadomości;
- tłumaczenia wiadomości wyświetlane w wybranym oknie czatu;
- osobne ustawienia widoku tłumaczeń w oknie czatu;
- podgląd tłumaczenia przed wstawieniem go do pola wiadomości;
- ręczne wysyłanie przez standardowy przycisk Steam, co zapobiega przypadkowemu
  podwójnemu wysyłaniu wiadomości.

WYMAGANIA

- Steam dla Windows;
- Millennium dla Steam;
- konto Google Cloud z aktywnym rozliczaniem;
- klucz API Google Cloud Translation.

CZYM JEST MILLENNIUM

Millennium to otwartoźródłowa platforma rozszerzeń dla desktopowego klienta Steam.
Pozwala instalować w Steam dodatki i motywy.

Oficjalna strona i dokumentacja:
https://docs.steambrew.app/

INSTALACJA MILLENNIUM W WINDOWS

1. Zamknij Steam.
2. Otwórz oficjalną stronę instalacji Millennium:
   https://docs.steambrew.app/users/getting-started/installation
3. Pobierz plik MillenniumInstaller-Windows.exe z podanej strony.
4. Uruchom instalator i wykonaj jego instrukcje.
5. Uruchom Steam ponownie.
6. W menu Steam, w lewym górnym rogu, powinno być widoczne Millennium.

INSTALACJA DODATKU

1. Rozpakuj pobrane archiwum ZIP do dowolnego folderu.
2. W Steam otwórz Steam > Millennium > Plugins / Wtyczki.
3. Wybierz "Install plugin" / "Zainstaluj wtyczkę".
4. Wskaż plik:
   Steam Chat Translator for Millennium by TW.star
5. Włącz dodatek przełącznikiem na liście wtyczek.
6. Otwórz menu przy dodatku i wybierz "Restart".

PIERWSZE URUCHOMIENIE I KLUCZ API

UWAGA: dodatek korzysta z Google Cloud Translation API. Nie jest to klucz
Google Maps API.

1. Otwórz panel Google Cloud:
   https://console.cloud.google.com/
2. Utwórz nowy projekt albo wybierz istniejący.
3. Włącz rozliczanie dla projektu. Google wymaga aktywnego rozliczania dla
   Cloud Translation.
4. Włącz Cloud Translation API:
   https://console.cloud.google.com/apis/library/translate.googleapis.com
5. Otwórz stronę danych logowania:
   https://console.cloud.google.com/apis/credentials
6. Wybierz "Create credentials" > "API key" i skopiuj utworzony klucz.
7. Ze względów bezpieczeństwa ogranicz klucz do Cloud Translation API.
8. W Steam wejdź do Millennium > Plugins / Wtyczki, otwórz konfigurację
   dodatku i wklej klucz w polu "Google Cloud Translation API key".

Oficjalne instrukcje Google:
https://cloud.google.com/translate/docs/setup
https://cloud.google.com/docs/authentication/api-keys

JAK UŻYWAĆ

1. Otwórz okno rozmowy w Steam.
2. Ikona tłumaczenia przy polu wpisywania wiadomości otwiera podgląd tłumaczenia
   wychodzącej wiadomości. Wybierz język źródłowy i docelowy, a następnie
   wybierz "Wstaw tekst". Kliknij zwykłą strzałkę Steam, aby wysłać wiadomość.
3. Ikona oka otwiera ustawienia tłumaczeń przychodzących dla bieżącego czatu:
   możesz wybrać język źródłowy, docelowy oraz włączyć lub wyłączyć widok
   tłumaczeń.

BEZPIECZEŃSTWO I KOSZTY

Klucz API jest poufny. Nie udostępniaj go innym osobom i ustaw ograniczenie
wyłącznie do Cloud Translation API. Usługa Google Cloud może generować koszty;
sprawdzaj użycie i limity w konsoli Google Cloud.

OFICJALNE LINKI

Millennium: https://docs.steambrew.app/
Instalacja Millennium: https://docs.steambrew.app/users/getting-started/installation
Google Cloud Translation: https://cloud.google.com/translate/docs/setup
Zarządzanie kluczami API: https://cloud.google.com/docs/authentication/api-keys
