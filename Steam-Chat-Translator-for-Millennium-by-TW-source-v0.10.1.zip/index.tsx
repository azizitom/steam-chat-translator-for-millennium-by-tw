import { definePlugin, DialogControlsSection, Field, Millennium, pluginConfig, subscribePluginConfig, TextField, usePluginConfig } from "millennium";

const PREFIX = "[Steam Chat Translator for Millennium by TW v0.10.1]";
const MAX_INITIAL_HISTORY = 12;
const LANGUAGES = [
  ["pl", "Polish"], ["ru", "Russian"], ["uk", "Ukrainian"],
  ["en", "English"], ["de", "German"], ["fr", "French"],
  ["es", "Spanish"], ["it", "Italian"], ["cs", "Czech"],
] as const;
const CHAT_ROOT_SELECTORS = [
  '[class*="ChatRoom"]',
  '[class*="friendChat"]',
  '[class*="FriendsList"]',
  '[class*="Conversation"]',
];
const MESSAGE_SELECTORS = [
  '[class*="ChatMessage"]',
  '[class*="ChatEntry"]',
  '[class*="MessageBody"]',
  '[class*="messageContent"]',
];

let observer: MutationObserver | undefined;
let friendsObserver: MutationObserver | undefined;
let lastSignature = "";
let scanQueued = false;
let friendsScanQueued = false;
const translatedMessages = new WeakSet<Element>();
const hookedComposers = new WeakSet<Element>();
const visibilityButtonComposers = new WeakMap<Element, Element>();
let outgoingSourceLanguage = "pl";
let outgoingTargetLanguage = "ru";
type ChatPreference = { enabled: boolean; source: string; target: string };
let chatPreferences: Record<string, ChatPreference> = {};
const memoryCache = new Map<string, string>();

function shortText(value: string): string {
  return value.replace(/\s+/g, " ").trim().slice(0, 180);
}

function countMatches(selectors: string[], root: ParentNode = document): number {
  const found = new Set<Element>();
  for (const selector of selectors) {
    root.querySelectorAll(selector).forEach((element) => found.add(element));
  }
  return found.size;
}

function messagePreview(root: ParentNode = document): string[] {
  const found = new Set<Element>();
  for (const selector of MESSAGE_SELECTORS) {
    root.querySelectorAll(selector).forEach((element) => found.add(element));
  }
  return [...found]
    .map((element) => shortText(element.textContent ?? ""))
    .filter(Boolean)
    .slice(-3);
}

function isDomQueryRoot(value: unknown): value is Element {
  return (
    typeof value === "object" &&
    value !== null &&
    "querySelectorAll" in value &&
    typeof (value as ParentNode).querySelectorAll === "function"
  );
}

function decodeHtml(value: string): string {
  const textarea = document.createElement("textarea");
  textarea.innerHTML = value;
  return textarea.value;
}

function stripMessageTimestamp(value: string): string {
  return value.replace(
    /^(?:(?:dzisiaj|wczoraj|today|yesterday|poniedziałek|wtorek|środa|czwartek|piątek|sobota|niedziela|monday|tuesday|wednesday|thursday|friday|saturday|sunday|понедельник|вторник|среда|четверг|пятница|суббота|воскресенье),?\s*)?(?:(?:\d{1,2}\s+[\p{L}.]+\s+\d{4},?\s*)?)?\d{1,2}:\d{2}\s*/iu,
    "",
  );
}

function cleanMessageText(element: Element): string {
  const preferred = [...element.querySelectorAll(
    '[class*="MessageText"], [class*="messageText"], [class*="MessageBody"], [class*="messageBody"], [class*="ChatMessage_Text"]',
  )]
    .map((node) => (node.textContent ?? "").replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .sort((a, b) => b.length - a.length)[0];
  if (preferred) return stripMessageTimestamp(preferred);
  const copy = element.cloneNode(true) as Element;
  copy.querySelectorAll(
    '[data-sct-translation], time, img, [class*="Timestamp"], [class*="timestamp"], [class*="Author"], [class*="author"], [class*="Username"], [class*="username"], [class*="Avatar"], [class*="avatar"], [class*="Header"], [class*="header"], [class*="Name"], [class*="name"]',
  ).forEach((node) => node.remove());
  return stripMessageTimestamp((copy.textContent ?? "").replace(/\s+/g, " ").trim());
}

function isValueComposer(composer: Element): composer is Element & { value: string } {
  return "value" in composer && typeof (composer as { value?: unknown }).value === "string";
}

function composerText(composer: Element): string {
  if (isValueComposer(composer)) return composer.value.trim();
  return (composer.textContent ?? "").trim();
}

function setComposerText(composer: Element, value: string): void {
  const view = composer.ownerDocument.defaultView ?? window;
  composer.focus();
  if (isValueComposer(composer)) {
    const prototype = Object.getPrototypeOf(composer) as { __lookupSetter__?: (name: string) => ((next: string) => void) | undefined };
    const setValue = prototype.__lookupSetter__?.("value");
    if (setValue) setValue.call(composer, value);
    else composer.value = value;
  } else {
    // Steam's contenteditable composer treats execCommand("insertText") as a
    // second user insertion. Replace the DOM content once, then notify Steam.
    composer.textContent = value;
  }
  composer.dispatchEvent(new view.Event("input", { bubbles: true }));
}

function findSteamSendButton(composer: Element): HTMLButtonElement | undefined {
  const container = composer.closest("form, [class*='chatEntry'], [class*='ChatEntry'], [class*='input'], [class*='Input']") ?? composer.parentElement;
  return [...(container?.querySelectorAll("button") ?? [])]
    .find((button) => button.tagName === "BUTTON" && button.offsetParent !== null && !button.dataset.sctSend) as HTMLButtonElement | undefined;
}

function findChatRoot(element: Element): Element {
  return element.closest("[class*='chatWindow'], [class*='ChatWindow'], [class*='ChatRoom'], [class*='Conversation']") ?? element.parentElement ?? element;
}

function stableHash(value: string): string {
  let hash = 5381;
  for (let index = 0; index < value.length; index += 1) hash = ((hash << 5) + hash) ^ value.charCodeAt(index);
  return (hash >>> 0).toString(36);
}

function chatPreferenceId(root: Element): string {
  const selector = "[data-chatid], [data-conversationid], [data-steamid], [data-groupid], [data-lobbyid], [class*='ChatRoomHeader'], [class*='chatRoomHeader'], [class*='ChatRoomTitle'], [class*='chatRoomTitle'], [class*='ChatRoomGroup'], [class*='chatRoomGroup'], [class*='ConversationHeader'], [class*='conversationHeader'], [aria-selected='true'], a[href*='chat'], a[href*='message']";
  const candidates = [...root.querySelectorAll(selector)].filter((node) => (node as HTMLElement).offsetParent !== null);
  const titles = [...new Set(candidates
    .map((node) => (node as HTMLElement).innerText ?? node.textContent ?? "")
    .map((text) => text.replace(/\s+/g, " ").trim())
    .filter((text) => text.length > 0 && text.length <= 120))];
  const nodes = [root, ...candidates].filter((node): node is Element => Boolean(node));
  const attributes = nodes.flatMap((node) => [...node.attributes]
    .filter((attribute) => /chat|conversation|steam|group|lobby|room|href|title|label/i.test(attribute.name))
    .map((attribute) => `${attribute.name}=${attribute.value}`));
  const visibleLines = ((root as HTMLElement).innerText ?? root.textContent ?? "")
    .split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0 && line.length <= 120).slice(0, 6);
  return stableHash([...attributes, ...titles, ...visibleLines].join("|"));
}

function chatPreference(root: Element): ChatPreference {
  return chatPreferences[chatPreferenceId(root)] ?? { enabled: true, source: "auto", target: outgoingSourceLanguage };
}

function applyChatPreference(root: Element, preference: ChatPreference): void {
  const id = chatPreferenceId(root);
  chatPreferences[id] = preference;
  root.querySelectorAll<HTMLElement>("[data-sct-translation]").forEach((label) => { label.style.display = preference.enabled ? "" : "none"; });
  void backend.saveChatTranslationPreference(JSON.stringify({ id, preference }));
  void backend.reportDiagnostic(`Saved translation preference for chat ${id}.`);
}

function refreshVisibilityButton(button: Element, composer: Element): void {
  const enabled = chatPreference(findChatRoot(composer)).enabled;
  button.title = enabled ? "Ustawienia tłumaczenia tego czatu" : "Tłumaczenia wyłączone — otwórz ustawienia czatu";
  button.setAttribute("aria-label", button.title);
  (button as HTMLElement).style.opacity = enabled ? "1" : "0.42";
}

function refreshVisibilityButtons(root: ParentNode): void {
  root.querySelectorAll("[data-sct-visibility]").forEach((button) => {
    const composer = visibilityButtonComposers.get(button);
    if (composer) refreshVisibilityButton(button, composer);
  });
}

function showOutgoingPreview(composer: Element, original: string, translated: string): void {
  const modal = composer.ownerDocument.createElement("div");
  modal.dataset.sctPreview = "true";
  modal.style.cssText = "position:fixed;z-index:2147483647;left:50%;top:50%;transform:translate(-50%,-50%);width:min(520px,calc(100vw - 32px));padding:18px;border:1px solid #6a90b8;border-radius:6px;background:#202b38;color:#fff;box-shadow:0 12px 40px #000;font:14px Arial,sans-serif;";
  const title = composer.ownerDocument.createElement("div");
  title.textContent = "Podgląd tłumaczenia przed wysłaniem";
  title.style.cssText = "font-size:17px;font-weight:bold;margin-bottom:10px;";
  const text = composer.ownerDocument.createElement("div");
  text.textContent = translated;
  text.style.cssText = "white-space:pre-wrap;padding:12px;background:#111923;border-radius:4px;max-height:220px;overflow:auto;";
  let selectedTranslation = translated;
  const footer = composer.ownerDocument.createElement("div");
  footer.style.cssText = "display:flex;gap:12px;justify-content:space-between;align-items:flex-end;margin-top:14px;";
  const languages = composer.ownerDocument.createElement("div");
  languages.style.cssText = "display:flex;gap:6px;align-items:center;";
  const sourceSelect = composer.ownerDocument.createElement("select");
  const targetSelect = composer.ownerDocument.createElement("select");
  const selectStyle = "max-width:125px;padding:6px;border:1px solid #52677d;border-radius:3px;background:#111923;color:#d6d7d8;font-size:12px;";
  sourceSelect.style.cssText = selectStyle;
  targetSelect.style.cssText = selectStyle;
  for (const [code, name] of LANGUAGES) {
    const sourceOption = composer.ownerDocument.createElement("option");
    sourceOption.value = code;
    sourceOption.textContent = `From: ${name}`;
    sourceSelect.appendChild(sourceOption);
    const targetOption = composer.ownerDocument.createElement("option");
    targetOption.value = code;
    targetOption.textContent = `To: ${name}`;
    targetSelect.appendChild(targetOption);
  }
  sourceSelect.value = outgoingSourceLanguage;
  targetSelect.value = outgoingTargetLanguage;
  const refreshTranslation = (): void => {
    outgoingSourceLanguage = sourceSelect.value;
    outgoingTargetLanguage = targetSelect.value;
    text.textContent = "Tłumaczę…";
    void backend.saveOutgoingLanguages(JSON.stringify({ source: outgoingSourceLanguage, target: outgoingTargetLanguage }));
    void (async () => {
      const next = decodeHtml(await backend.translateOutgoingWithLanguages(JSON.stringify({ text: original, source: outgoingSourceLanguage, target: outgoingTargetLanguage })));
      if (next) {
        selectedTranslation = next;
        text.textContent = next;
      } else text.textContent = "Nie udało się uzyskać tłumaczenia dla wybranej pary języków.";
    })();
  };
  sourceSelect.onchange = refreshTranslation;
  targetSelect.onchange = refreshTranslation;
  languages.append(sourceSelect, targetSelect);
  const actions = composer.ownerDocument.createElement("div");
  actions.style.cssText = "display:flex;gap:10px;justify-content:flex-end;";
  const cancel = composer.ownerDocument.createElement("button");
  cancel.textContent = "Anuluj";
  const send = composer.ownerDocument.createElement("button");
  send.textContent = "Wstaw tekst";
  send.style.cssText = "background:#4c91d1;color:white;border:0;border-radius:3px;padding:8px 12px;";
  cancel.onclick = () => modal.remove();
  send.onclick = () => {
    setComposerText(composer, selectedTranslation);
    modal.remove();
    void backend.reportDiagnostic("Translated text inserted into the composer; waiting for the user's normal Steam send click.");
  };
  actions.append(cancel, send);
  footer.append(languages, actions);
  modal.append(title, text, footer);
  composer.ownerDocument.body.appendChild(modal);
}

function showChatTranslationSettings(composer: Element, button: Element): void {
  const chatRoot = findChatRoot(composer);
  const current = chatPreference(chatRoot);
  const modal = composer.ownerDocument.createElement("div");
  modal.dataset.sctChatSettings = "true";
  modal.style.cssText = "position:fixed;z-index:2147483647;left:50%;top:50%;transform:translate(-50%,-50%);width:min(460px,calc(100vw - 32px));padding:18px;border:1px solid #6a90b8;border-radius:6px;background:#202b38;color:#fff;box-shadow:0 12px 40px #000;font:14px Arial,sans-serif;";
  const title = composer.ownerDocument.createElement("div");
  title.textContent = "Tłumaczenia w tym czacie";
  title.style.cssText = "font-size:17px;font-weight:bold;margin-bottom:12px;";
  const enabledLabel = composer.ownerDocument.createElement("label");
  enabledLabel.style.cssText = "display:flex;gap:8px;align-items:center;margin-bottom:14px;";
  const enabledInput = composer.ownerDocument.createElement("input");
  enabledInput.type = "checkbox";
  enabledInput.checked = current.enabled;
  enabledLabel.append(enabledInput, composer.ownerDocument.createTextNode("Pokazuj tłumaczenia w tym czacie"));
  const languageTitle = composer.ownerDocument.createElement("div");
  languageTitle.textContent = "Tłumaczenie wiadomości: język oryginalny → język docelowy";
  languageTitle.style.cssText = "margin-bottom:7px;opacity:.85;";
  const languages = composer.ownerDocument.createElement("div");
  languages.style.cssText = "display:flex;gap:8px;";
  const sourceSelect = composer.ownerDocument.createElement("select");
  const targetSelect = composer.ownerDocument.createElement("select");
  const selectStyle = "flex:1;min-width:0;padding:7px;border:1px solid #52677d;border-radius:3px;background:#111923;color:#d6d7d8;";
  sourceSelect.style.cssText = selectStyle;
  targetSelect.style.cssText = selectStyle;
  const automatic = composer.ownerDocument.createElement("option");
  automatic.value = "auto";
  automatic.textContent = "From: Auto detect";
  sourceSelect.appendChild(automatic);
  for (const [code, name] of LANGUAGES) {
    const sourceOption = composer.ownerDocument.createElement("option");
    sourceOption.value = code;
    sourceOption.textContent = `From: ${name}`;
    sourceSelect.appendChild(sourceOption);
    const targetOption = composer.ownerDocument.createElement("option");
    targetOption.value = code;
    targetOption.textContent = `To: ${name}`;
    targetSelect.appendChild(targetOption);
  }
  sourceSelect.value = current.source;
  targetSelect.value = current.target;
  languages.append(sourceSelect, targetSelect);
  const footer = composer.ownerDocument.createElement("div");
  footer.style.cssText = "display:flex;justify-content:flex-end;margin-top:16px;";
  const close = composer.ownerDocument.createElement("button");
  close.textContent = "Zapisz";
  close.style.cssText = "background:#4c91d1;color:#fff;border:0;border-radius:3px;padding:8px 14px;";
  close.onclick = () => {
    const preference = { enabled: enabledInput.checked, source: sourceSelect.value, target: targetSelect.value };
    applyChatPreference(chatRoot, preference);
    refreshVisibilityButton(button, composer);
    if (preference.enabled) void translateIncomingMessages(chatRoot);
    modal.remove();
  };
  footer.appendChild(close);
  modal.append(title, enabledLabel, languageTitle, languages, footer);
  composer.ownerDocument.body.appendChild(modal);
}

function hookOutgoingComposer(composer: Element): void {
  if (hookedComposers.has(composer)) return;
  hookedComposers.add(composer);
  const oldSteamSend = findSteamSendButton(composer);
  oldSteamSend?.parentElement?.querySelectorAll("[data-sct-send], [data-sct-visibility]").forEach((oldButton) => oldButton.remove());
  const button = composer.ownerDocument.createElement("button");
  button.type = "button";
  button.dataset.sctSend = "true";
  const icon = '<svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true"><path d="M5 5h25v26H5z" fill="#f1f3f4" stroke="#9aa0a6" stroke-width="2"/><text x="10" y="25" fill="#5f6368" font-family="Arial, sans-serif" font-size="17" font-weight="700">文</text><path d="M20 14h22v27H20z" fill="#4285f4"/><path d="M20 14h14l8 8H20z" fill="#8ab4f8"/><text x="25" y="35" fill="#fff" font-family="Arial, sans-serif" font-size="20" font-weight="700">G</text></svg>';
  button.innerHTML = icon;
  button.title = "Przetłumacz wiadomość";
  button.setAttribute("aria-label", "Przetłumacz wiadomość");
  button.style.cssText = "box-sizing:border-box;display:flex;align-items:center;justify-content:center;width:58px;height:47px;min-height:47px;max-height:47px;margin:8px 0 1px 0;padding:0;border:1px solid #080b0e;border-radius:0;background:#293341;color:#66c0f4;box-shadow:inset 0 0 0 1px #3b4654;cursor:pointer;overflow:hidden;";
  button.onclick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    void (async () => {
      const original = composerText(composer);
      if (!original || original.length > 5000) return;
      if (outgoingSourceLanguage === outgoingTargetLanguage) {
        void backend.reportDiagnostic("Outgoing translation skipped because source and target languages are the same.");
        return;
      }
      button.disabled = true;
      button.textContent = "…";
      const translated = decodeHtml(await backend.translateOutgoing(original));
      button.disabled = false;
      button.innerHTML = icon;
      if (!translated) { void backend.reportDiagnostic("Outgoing translation failed; preview was not opened."); return; }
      showOutgoingPreview(composer, original, translated);
    })();
  };
  const visibilityButton = composer.ownerDocument.createElement("button");
  visibilityButton.type = "button";
  visibilityButton.dataset.sctVisibility = "true";
  visibilityButton.innerHTML = '<svg viewBox="0 0 24 24" width="23" height="23" aria-hidden="true"><path fill="currentColor" d="M12 5c-5.4 0-9.4 4.1-10.7 7 1.3 2.9 5.3 7 10.7 7s9.4-4.1 10.7-7C21.4 9.1 17.4 5 12 5Zm0 11.5A4.5 4.5 0 1 1 12 7a4.5 4.5 0 0 1 0 9.5Zm0-2A2.5 2.5 0 1 0 12 9a2.5 2.5 0 0 0 0 5.5Z"/></svg>';
  visibilityButton.style.cssText = "box-sizing:border-box;display:flex;align-items:center;justify-content:center;width:56px;height:47px;min-height:47px;max-height:47px;margin:8px 6px 1px 0;padding:0;border:1px solid #080b0e;border-radius:0;background:#293341;color:#66c0f4;box-shadow:inset 0 0 0 1px #3b4654;cursor:pointer;";
  visibilityButtonComposers.set(visibilityButton, composer);
  refreshVisibilityButton(visibilityButton, composer);
  visibilityButton.onclick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    showChatTranslationSettings(composer, visibilityButton);
  };
  const steamSend = findSteamSendButton(composer);
  const anchor = steamSend?.parentElement ?? composer.parentElement ?? composer;
  if (steamSend?.parentElement === anchor) {
    anchor.insertBefore(button, steamSend.nextSibling);
    anchor.insertBefore(visibilityButton, button.nextSibling);
  } else {
    anchor.append(button, visibilityButton);
  }
}

function hookOutgoingComposers(root: ParentNode): void {
  root.querySelectorAll('textarea, [contenteditable="true"], input[type="text"]').forEach(hookOutgoingComposer);
}

async function translateIncomingMessages(root: ParentNode): Promise<void> {
  const selectedChatRoot = isDomQueryRoot(root)
    ? root.querySelector("[class*='chatWindow'], [class*='ChatWindow'], [class*='ChatRoom'], [class*='Conversation']") ?? root
    : undefined;
  const preference = selectedChatRoot ? chatPreference(selectedChatRoot) : { enabled: true, source: "auto", target: outgoingSourceLanguage };
  if (!preference.enabled) return;
  const messages = new Set<Element>();
  for (const selector of MESSAGE_SELECTORS) root.querySelectorAll(selector).forEach((element) => messages.add(element));
  const leafMessages = [...messages].filter(
    (message) => ![...messages].some((other) => other !== message && message.contains(other)),
  );
  const candidates = leafMessages
    .filter((message) => !translatedMessages.has(message) && !message.querySelector("[data-sct-translation]"))
    .slice(-MAX_INITIAL_HISTORY)
    .reverse();
  for (const message of candidates) {
    if (translatedMessages.has(message) || message.querySelector("[data-sct-translation]")) continue;
    const original = cleanMessageText(message);
    if (!original || original.length > 5000) continue;
    translatedMessages.add(message);
    const cacheKey = `${preference.source}>${preference.target}\u001f${original}`;
    const cached = memoryCache.get(cacheKey);
    const translated = cached ?? decodeHtml(await backend.translateIncomingWithLanguages(JSON.stringify({ text: original, source: preference.source, target: preference.target })));
    if (!translated) continue;
    memoryCache.set(cacheKey, translated);
    const label = message.ownerDocument.createElement("div");
    label.dataset.sctTranslation = "true";
    label.textContent = `Translation: ${translated}`;
    label.style.cssText = "margin-top:4px; opacity:.8; font-style:italic;";
    message.appendChild(label);
  }
}

function scan(reason: string): void {
  scanQueued = false;
  const chatRoots = countMatches(CHAT_ROOT_SELECTORS);
  const messageCount = countMatches(MESSAGE_SELECTORS);
  const inputs = document.querySelectorAll('textarea, [contenteditable="true"], input[type="text"]').length;
  const previews = messagePreview();
  const signature = `${chatRoots}|${messageCount}|${inputs}|${previews.join("\u001f")}`;

  if (signature === lastSignature && reason === "mutation") return;
  lastSignature = signature;

  console.info(`${PREFIX} scan=${reason}`, {
    url: location.href,
    title: document.title,
    chatRoots,
    messageCount,
    composerInputs: inputs,
    recentMessagePreviews: previews,
  });

  if (chatRoots > 0 || messageCount > 0) {
    console.info(`${PREFIX} CHAT DETECTED: roots=${chatRoots}, messages=${messageCount}, inputs=${inputs}`);
    void backend.reportDiagnostic(
      `CHAT DETECTED (${reason}): roots=${chatRoots}, messages=${messageCount}, inputs=${inputs}`,
    );
  } else {
    console.info(`${PREFIX} Chat not visible yet; open Friends & Chat and then a conversation.`);
    void backend.reportDiagnostic(`scan=${reason}: chat not visible yet`);
  }
}

function queueMutationScan(): void {
  if (scanQueued) return;
  scanQueued = true;
  window.setTimeout(() => scan("mutation"), 350);
}

function startDiagnostics(): void {
  console.info(`${PREFIX} frontend loaded`, { url: location.href, title: document.title });
  void backend.reportDiagnostic(`frontend loaded: title=${document.title || "(no title)"}`);
  scan("startup");
  observer?.disconnect();
  observer = new MutationObserver(queueMutationScan);
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  window.setInterval(() => scan("interval"), 5000);
}

function inspectNewWindow(context: unknown): void {
  const candidate = context as Record<string, unknown> | null;
  const keys = candidate ? Object.keys(candidate).slice(0, 12).join(",") : "none";
  const title = candidate && typeof candidate.m_strTitle === "string" ? candidate.m_strTitle : "(unknown)";
  console.info(`${PREFIX} Steam window created`, { title, keys });
  void backend.reportDiagnostic(`window created: title=${title}; fields=${keys || "none"}`);

  if (title !== "Lista znajomych" && title !== "") return;
  const childViews = candidate?.m_rgChildBrowserViews;
  const childCount = Array.isArray(childViews) ? childViews.length : 0;
  void backend.reportDiagnostic(`Friends window child browser views: ${childCount}`);

  let attempts = 0;
  const waitForFriendsHost = window.setInterval(() => {
    attempts += 1;
    const host = candidate?.m_element;
    if (!isDomQueryRoot(host)) {
      if (attempts === 1 || attempts === 10) {
        const type = host === null ? "null" : typeof host;
        const fields = host && typeof host === "object" ? Object.keys(host as object).slice(0, 8).join(",") : "none";
        void backend.reportDiagnostic(`Friends window host not ready (${attempts}/10): type=${type}; fields=${fields || "none"}`);
      }
      if (attempts >= 10) window.clearInterval(waitForFriendsHost);
      return;
    }
    window.clearInterval(waitForFriendsHost);

    const hostClass = String(host.className || "");
    const looksLikeChat = /chat|friend/i.test(hostClass);
    if (title !== "Lista znajomych" && !looksLikeChat) return;

      const scanFriendsWindow = (reason: string): void => {
      const roots = countMatches(CHAT_ROOT_SELECTORS, host);
      const messages = countMatches(MESSAGE_SELECTORS, host);
      const inputs = host.querySelectorAll('textarea, [contenteditable="true"], input[type="text"]').length;
      const previews = messagePreview(host);
      void backend.reportDiagnostic(
        `FRIENDS WINDOW ${reason}: roots=${roots}, messages=${messages}, inputs=${inputs}, host=${host.tagName}.${host.className || "(no-class)"}`,
      );
      if (messages > 0) console.info(`${PREFIX} FRIENDS WINDOW MESSAGE ELEMENTS`, previews);
      void translateIncomingMessages(host);
      const activeChat = host.querySelector("[class*='chatWindow'], [class*='ChatWindow'], [class*='ChatRoom'], [class*='Conversation']") ?? host;
      const displayIncomingTranslations = chatPreference(activeChat).enabled;
      host.querySelectorAll<HTMLElement>("[data-sct-translation]").forEach((label) => { label.style.display = displayIncomingTranslations ? "" : "none"; });
      hookOutgoingComposers(host);
      refreshVisibilityButtons(host);
    };

    const interestingClasses = [...host.querySelectorAll("[class]")]
      .map((element) => String(element.className || ""))
      .filter((className) => /chat|message|friend/i.test(className))
      .filter((className, index, all) => all.indexOf(className) === index)
      .slice(0, 24)
      .join(" | ");
    const embeddedFrames = host.querySelectorAll("iframe, webview").length;
    void backend.reportDiagnostic(`Friends window DOM host found: ${host.tagName}.${hostClass || "(no-class)"}`);
    void backend.reportDiagnostic(`Friends DOM shape: embeddedFrames=${embeddedFrames}; classes=${interestingClasses || "none"}`);
    window.setTimeout(() => scanFriendsWindow("initial"), 800);
    friendsObserver?.disconnect();
    friendsObserver = new MutationObserver(() => {
      if (friendsScanQueued) return;
      friendsScanQueued = true;
      window.setTimeout(() => {
        friendsScanQueued = false;
        scanFriendsWindow("mutation");
      }, 250);
    });
    friendsObserver.observe(host, { childList: true, subtree: true, characterData: true });
  }, 500);
}

export default definePlugin(() => {
  startDiagnostics();
  void pluginConfig.get<string>("outgoing_source_language").then((value) => { if (value) outgoingSourceLanguage = value; });
  void pluginConfig.get<string>("outgoing_target_language").then((value) => { if (value) outgoingTargetLanguage = value; });
  void pluginConfig.get<string>("chat_translation_preferences").then((value) => {
    try { chatPreferences = JSON.parse(value ?? "{}"); } catch { chatPreferences = {}; }
  });
  subscribePluginConfig((key, value) => {
    if (key === "outgoing_source_language" && typeof value === "string") outgoingSourceLanguage = value;
    if (key === "outgoing_target_language" && typeof value === "string") outgoingTargetLanguage = value;
    if (key === "chat_translation_preferences" && typeof value === "string") {
      try { chatPreferences = JSON.parse(value); } catch { chatPreferences = {}; }
    }
  });
  if (Millennium.AddWindowCreateHook) {
    Millennium.AddWindowCreateHook(inspectNewWindow);
    void backend.reportDiagnostic("registered Steam window diagnostic hook");
  } else {
    void backend.reportDiagnostic("window diagnostic hook unavailable in this UI context");
  }
  return {
    title: "Steam Chat Translator for Millennium by TW",
    icon: <span>🌐</span>,
    content: <SettingsContent />,
  };
});

function SettingsContent() {
  const [apiKey, setApiKey] = usePluginConfig<string>("google_api_key");
  return (
    <DialogControlsSection>
      <div style={{ marginTop: "14px" }}>
        <div style={{ fontSize: "15px", fontWeight: 600, marginBottom: "8px" }}>Google Cloud Translation API key</div>
        <div style={{ marginBottom: "8px", opacity: 0.75 }}>Stored locally in Millennium and sent only to Google Cloud Translation for enabled translations.</div>
        <TextField
          bIsPassword
          placeholder="Paste the API key here"
          value={apiKey ?? ""}
          onChange={(event) => setApiKey(event.target.value)}
        />
      </div>
      <Field
        label="Translation controls"
        description={apiKey ? "Choose outgoing languages with the translation icon. Use the eye icon in each chat to configure its incoming translations and visibility." : "Enter an API key to enable translation controls in chat."}
      />
    </DialogControlsSection>
  );
}
